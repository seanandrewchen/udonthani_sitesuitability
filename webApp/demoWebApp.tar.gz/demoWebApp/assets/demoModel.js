(function(){

    var app = angular.module('demoModel',[]);

    app.controller('ModelController',['$scope',function($scope){

        //outputs
        $scope.current_damages = 500000;
        $scope.current_flooding = 50000;
        $scope.current_watersupply = 100000;

        //inputs
        $scope.current_spending = 1000000;
        $scope.infrastructure_options = [{type: 'Green'}, {type: 'Traditional'}];
        $scope.current_infrastructure = [{type: 'Green'}];

        $scope.calculate = function(){
            
            if($scope.current_infrastructure == $scope.infrastructure_options[1]){
                $scope.current_flooding = $scope.current_spending * .75;
            }
            else{
                $scope.current_flooding = $scope.current_spending * .5;
            }

            $scope.current_watersupply = .75 * $scope.current_flooding;
            $scope.current_damages = $scope.current_flooding * 10;

        };

        $scope.calculate();

    }]);

})();